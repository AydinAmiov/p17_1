package com.example.pincode

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class PinCodeActivity : AppCompatActivity() {
    private var pinCode: String?= null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pin_code)
        val sharedPreferences=getSharedPreferences("Пин Код", Context.MODE_PRIVATE)
        pinCode= sharedPreferences.getString("Пин Код",null)
        if(pinCode==null){
            showPinCodeScreen()
        }else{
            showPinCodeVerifyScreen()
        }
    }
    @SuppressLint("MissingInflatedId")
    private fun showPinCodeScreen() {
        setContentView(R.layout.activity_pin_code)

        val btnConfirm = findViewById<Button>(R.id.btn_confirm)
        val inputPinCode = findViewById<EditText>(R.id.input_pin_code)

        btnConfirm.setOnClickListener {
            if (inputPinCode.text.toString() == "2038") {
                pinCode = inputPinCode.text.toString()

                val sharedPreferences = getSharedPreferences("", Context.MODE_PRIVATE)
                sharedPreferences.edit().putString("ПинКод", pinCode).apply()

                showInfoScreen()
            } else {
                Toast.makeText(this, "Неверный пин код", Toast.LENGTH_SHORT).show()
            }
        }
    }
    @SuppressLint("MissingInflatedId")
    private fun showPinCodeVerifyScreen() {
        setContentView(R.layout.activity_main)
        val btnConfirm = findViewById<Button>(R.id.btn_confirm)
        val inputPinCode = findViewById<EditText>(R.id.input_pin_code)

        btnConfirm.setOnClickListener {
            if (inputPinCode.text.toString() == pinCode) {
                showInfoScreen()
            } else {
                Toast.makeText(this, "Неверный пин код", Toast.LENGTH_SHORT).show()
            }
        }
    }
    private fun showInfoScreen() {
        val intent = Intent(this, MainActivity::class.java)
        startActivity(intent)
        finish()
    }
}